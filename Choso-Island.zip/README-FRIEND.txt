Choso Island — friend test build

Requirements
- Apple Silicon only (arm64). Will not run on Intel Macs.
- macOS 14 or newer.

Install
1. Unzip this archive.
2. Drag "Choso Island.app" into Applications (recommended).
3. First launch: right-click the app → Open → click Open again (Gatekeeper).
   Do not double-click the first time — macOS may block unsigned/ad-hoc apps.
4. If still blocked: System Settings → Privacy & Security → scroll down → Open Anyway.
5. Grant Accessibility when macOS asks (needed for volume / brightness HUD).
   Path: System Settings → Privacy & Security → Accessibility → enable Choso Island.
6. Optional: Calendar for the calendar tab; music app permissions if prompted.

What to try
- Play a song (Apple Music / Spotify / YouTube Music) — album left, waveform right on the closed notch.
- Hover the notch to open the island; click album art for immersive lyrics.
- Lock & unlock the Mac to see the fingerprint unlock animation (if enabled in Settings).
- Drop a file onto the closed notch for the Shelf.

Notes
- This zip is ad-hoc signed for sharing. Each new build may re-ask Accessibility / Calendar — normal.
- After granting Accessibility: Quit Choso Island fully, then reopen (HUDs need a relaunch).
- Sparkle auto-update is not used on this test zip.
- Charge-limit features need a recent macOS on Apple silicon.
